﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menuu : MonoBehaviour
{
    private Button BackMenuButton;
    private Button RestartButton;

    private void Awake()
    {
        RestartButton = GameObject.Find("RestartButton").GetComponent<Button>();
        BackMenuButton = GameObject.Find("BackMenuButton").GetComponent<Button>();
    }

    private void Start()
    {
        BackMenuButton.onClick.AddListener(BackMenu);
        RestartButton.onClick.AddListener(RestartGame);
    }

    private void BackMenu()
    {
        SceneManager.LoadScene(0);
    }

    private void RestartGame()
    {
        SceneManager.LoadScene(1);
    }
}
