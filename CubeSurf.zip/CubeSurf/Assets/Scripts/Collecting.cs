﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Collecting : MonoBehaviour
{ 
    [SerializeField] private AudioClip TakeCube;
    [SerializeField] private AudioSource VoiceSource;
    
    private GameObject MainCube;
    private int Height;

    private Text CoinText;
    [SerializeField] private AudioClip TakeCoin;
    private int Coins = 0;
    
    
    private void Awake()
    {
        CoinText = GameObject.Find("CoinText").GetComponent<Text>();
    }

    private void Start()
    {
        CoinText.text = Coins.ToString();
        MainCube = GameObject.Find("MainCube");
    }

    private void Update()
    {
        MainCube.transform.position = new Vector3(transform.position.x, Height + 1, transform.position.z);
        this.transform.localPosition = new Vector3(0, -Height, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("collectable")&& other.gameObject.GetComponent<CollectableCube>().GetWasitTaken() == false)
        {
            VoiceSource.PlayOneShot(TakeCube);
            Height++;
            other.gameObject.GetComponent<CollectableCube>().DoitTaken();
            other.gameObject.GetComponent<CollectableCube>().EditIndex(Height);
            other.gameObject.transform.parent = MainCube.transform;
        }

        if (other.gameObject.CompareTag("Coin"))
        {
            Coins++;
            CoinText.text = Coins.ToString();
            VoiceSource.PlayOneShot(TakeCoin);
            Destroy(other.gameObject);
        }
    }

    public void Azalt()
    {
        Height--;
    }
}
