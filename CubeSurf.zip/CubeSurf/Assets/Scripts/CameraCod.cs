﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCod : MonoBehaviour
{
    private GameObject Target;
    private Vector3 Distance = new Vector3(10f, 7f, 10f);

    private void Awake()
    {
        Target = GameObject.FindWithTag("Player");
    }

    private void LateUpdate()
    {
        this.gameObject.transform.position = Vector3.Lerp(this.gameObject.transform.position,Target.transform.position + Distance, Time.deltaTime);
    }
}
