﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoseCheck : MonoBehaviour
{
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Barrier"))
        {
            SceneManager.LoadScene(2);
        }

        if (other.gameObject.CompareTag("finish"))
        {
            SceneManager.LoadScene(3);
        }
    }
}
