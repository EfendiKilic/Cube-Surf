﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPlay : MonoBehaviour
{
    private static MusicPlay SingleMusicPlayer = null;
    
    private void Start()
    {
        if (SingleMusicPlayer != null)
        {
            Destroy(gameObject);
        }
        else
        {
            SingleMusicPlayer = this;
            GameObject.DontDestroyOnLoad(this.gameObject);
        }
    }
}
