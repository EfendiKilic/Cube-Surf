﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectableCube : MonoBehaviour
{
    private bool WasitTaken;
    private int Index;
    public Collecting collecting;

    private void Update()
    {
        if (WasitTaken == true && transform.parent)
        {
            transform.localPosition = new Vector3(0, -Index, 0);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Barrier"))
        {
            collecting.Azalt();
            this.gameObject.transform.parent = null;
            this.gameObject.GetComponent<BoxCollider>().enabled = false;
            other.gameObject.GetComponent<BoxCollider>().enabled = false;
        }
    }

    public bool GetWasitTaken()
    {
        return WasitTaken;
    }

    public void DoitTaken()
    {
        WasitTaken = true;
    }

    public void EditIndex(int index)
    {
        this.Index = index;
    }
}
