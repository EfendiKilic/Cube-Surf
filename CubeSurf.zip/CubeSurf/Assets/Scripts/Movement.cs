﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    private float ForwardSpeed = 5f; 
    private float HorizontalSpeed = 10f;
    private float HorizontalAxes;
    private float MinLimit = -4.5f;
    private float MaxLimit = 4.5f;
    [SerializeField] private Joystick _joystick;
    
    private void Update()
    {
        HorizontalAxes = _joystick.Horizontal;
        HorizontalAxes *= HorizontalSpeed * Time.deltaTime;
        
        this.gameObject.transform.Translate(HorizontalAxes,0,ForwardSpeed*Time.deltaTime);

        
        if (this.gameObject.transform.position.z <= MinLimit)
        {
            this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x,this.gameObject.transform.position.y,MinLimit);
        }
        if (this.gameObject.transform.position.z >= MaxLimit)
        {
            this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x,this.gameObject.transform.position.y,MaxLimit);
        }
    }
}
